/****************************************************************************
* Project: RecursivePractice
* File: main.c
* Author: Gwendolyn Montague
* Date: 10/07/2020
* Description: This console-based program practices how to use recursion
*              to program a countdown clock.
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>

void countdown(int x);
int main()
{
    int x;
    printf("%s", "Enter the starting number for the timer: ");
    scanf("%d", &x);
    getchar();
    countdown(x);
}
void countdown(int x)
{
    if (x < 1)
        return;
    printf("%d\n", x);
    countdown(x-1);
}
